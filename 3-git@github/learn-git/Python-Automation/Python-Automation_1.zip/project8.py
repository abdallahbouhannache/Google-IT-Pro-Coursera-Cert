#!/usr/bin/env python3
import os
import zipfile 
import re

# Backup of folder into a zip file

# Copies the whole contents of any folder into a zip file whose filename increaments

# File format should be like this filename_number.zip (number should be increamented)


def backup(folder):
	# Backup the content of folder into a zip file

	folder = os.path.abspath(folder)
	number = 1

	while True:
		zip_name = os.path.basename(folder) + '_' + str(number) + '.zip'
		print("while")

		if os.path.exists(zip_name):
			print(f"{zip_name}file already exist quitting ..")
			break
		number = number + 1

		print ("Creating file %s" %(zip_name))

		backupzip = zipfile.ZipFile(zip_name,'w')

		# Walking through the whole directory
		for foldername, subfolders, filenames in os.walk(folder):
			if  len(foldername) and  not re.search(r'\.',foldername):
				print(foldername, subfolders, filenames)
				for filename in filenames:
					#filepath = os.path.join(foldername, filename)
					backupzip.write(filename)
		        # join the two strings in order to form the full filepath.
		            #.append(filepath)
				# for filename in filenames:
				# 	if not re.search(r'\.',filename):
				# 		print(filename)
				# 		if not re.search(r"\.",foldername):
				# 			print ('Adding the file %s'%(filenames))
				# 			backupzip.write(filenames)

				# if  len(subfolders) and  not re.search(r"\.",subfolders[0]):

		backupzip.close()
		

 #filepath = os.path.join(root, filename)


		# backupzip.close()
		# if not backupzip.size():
		# 	os.path.remove(zip_name)
		print ('Succeeded')
		break

# def main():
# 	backup()

backup("./")