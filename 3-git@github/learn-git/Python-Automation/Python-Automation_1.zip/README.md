### Automating Tasks using Python

These are some projects which I worked upon to automate stuffs using python.

- [Project 1](https://github.com/nitin42/Python-Automation/blob/master/project_1.py)  - E-mail and phone number extractor
- [Project 2](https://github.com/nitin42/Python-Automation/blob/master/project2.py)  - Strong Password Detection
- [Project 3](https://github.com/nitin42/Python-Automation/blob/master/project3.py)  - Regular expression version for strip()
- [Project 4](https://github.com/nitin42/Python-Automation/blob/master/project_4.py)  - Multiclipboard
- [Project 5](https://github.com/nitin42/Python-Automation/blob/master/project5.py) - Mad Libs
- [Project 6](https://github.com/nitin42/Python-Automation/blob/master/projec6.py)  - Regex Search()
- [Project 7](https://github.com/nitin42/Python-Automation/blob/master/project_7.py)  - Renaming the files
- [Project 8](https://github.com/nitin42/Python-Automation/blob/master/project8.py)  - Backup a file/folder into a zip file
- [Project 9](https://github.com/nitin42/Python-Automation/blob/master/project9.py)  - Map Me! 
- [Project 10](https://github.com/nitin42/Python-Automation/blob/master/project10.py) - Feeling Lucky Today!
- [Project 11](https://github.com/nitin42/Python-Automation/blob/master/2048.py) - 2048!
- [Project 12](https://github.com/nitin42/Python-Automation/blob/master/Project12.py) - Combining pages from PDFs
- [project 13](https://github.com/nitin42/Python-Automation/blob/master/project13.py) - Copying '.jpg' and '.pdf' files into a newfolder
- [Project 14](https://github.com/nitin42/Python-Automation/blob/master/project14.py) - Deleting Uneeded Files from PC
- [Project 15](https://github.com/nitin42/Python-Automation/blob/master/project15.py) - Brute-Force PDF Password Breaker
- [Project 16](https://github.com/nitin42/Python-Automation/blob/master/project16.py) - UNIX Password Cracker
- [Project 17](https://github.com/nitin42/Python-Automation/blob/master/project17.py) - ZIP Password Cracker
- [EASTER EGG FUN](https://github.com/nitin42/Python-Automation/blob/master/easter_egg.py) - Try it for fun!
- [Profanity check](https://github.com/nitin42/Python-Automation/blob/master/profanity_editor.py) - Save your A$$!
- [Pirate speech](https://github.com/nitin42/Python-Automation/blob/master/pirate_speech.py) - Translate into a pirate
- [Count Frequency](https://github.com/nitin42/Python-Automation/blob/master/count_me.py) - Counts the frequency of each word in a text file. 


